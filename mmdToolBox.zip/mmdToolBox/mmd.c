/* Calculates MMD of samples X and Y */
/* MMD uses Gaussian kernel k(x,y)=exp(gamma*\|x-y\|^2*/
/* calling sequence is MMD(X,Y,gamma) */
/* (c) DDE laboratory, Binghamton University, SUNY */
/* author: Tomas Pevny, pevnak@gmail.com */



#include "mex.h"
#include "matrix.h"
#include <math.h>

/* Translate Matlab array to C array. It is a column major notation.
data(i,j)=data[j*rows + i]  */
int getDoubleArray(const mxArray *arg, double** x, int* rows, int* colls) {
  if (!arg) return -1;
  *rows = (int) mxGetM(arg);
  *colls = (int) mxGetN(arg);
  if (!mxIsNumeric(arg) || mxIsComplex(arg) || mxIsSparse(arg)  || !mxIsDouble(arg) ) {
	mexPrintf("Type of array should be double");
    *x= NULL;
    return -1;
  }
  *x = mxGetPr(arg);
  return 1;
}


int getDouble(const mxArray *arg, double *x) {
  int m, n;

  if (!arg) return -1;
  m = mxGetM(arg);
  n = mxGetN(arg);
  if (!mxIsNumeric(arg) || mxIsComplex(arg) || mxIsSparse(arg)  || !mxIsDouble(arg) ||
      (m != 1) || (n != 1)) {
    *x = 0.0;
    return -1;
  }
  *x = mxGetScalar(arg);
  return 1;
}


/*dot product used in the calculation of MMD */
double dotProduct(double* x,double* y, int dim,double gamma){
	double result=0;
	int i=0;
	for(i=0;i<dim;i++) {
		double t=x[i]-y[i];
		result-=t*t;
		};
	return exp(gamma*result);
	}


/*Main function */
void mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[]){
  double *xData=NULL;
  double *yData=NULL;
  int xRows=0,xColls=0,yRows=0,yColls=0;
  int dim=0;
  int samples=0;
  double MMD=0.0,gamma=0.0;
  int i=0,j=0;

  if (nrhs<3) {
		mexPrintf("\nFunction needs 3 parameters: mmd(X,Y,gamma)\n");
		mexPrintf("X and Y are matrices with samples. Each column is one sample, both matrices has to have same number of rows.\n");
		mexPrintf("If the number of columns is different, MMD is calculated from the least number of samples.\n");
		mexPrintf("gamma is the width of Gaussian kernel k(x,y)=exp(-gamma*\\|x-y\\|^2)\n\n");
		return;
		};

	/*get matrices with samples */
	if ((getDoubleArray(prhs[0],&xData,&xRows,&xColls)==-1)||(getDoubleArray(prhs[1],&yData,&yRows,&yColls)==-1)){
		mexPrintf("Failed to extract matrices from the parameters.");
		return;
		};

	/* check if samples has the same dimension and set the number of samples used to calculate estimate of MMD */
	if (xRows!=yRows){
		return;
		};
	dim=yRows;

	samples=xColls;
	if (samples>yColls){
		mexPrintf("Only %d samples will be used to calculate MMD statistics\n",samples);
		};

	/*extract width of Gaussian kernel */
	gamma=0.0;
	if (getDouble(prhs[2],&gamma)==-1){
		mexPrintf("Failed to extract width of Gaussian kernel.\n");
		return;
		};

	/*now, we can finally calculate MMD value */
	MMD=0.0;

	/*mexPrintf("dimension %d  samples %d\n",dim,samples);*/
	for (i=0;i<samples;i++){
		for (j=0;j<i;j++){
			double h=0.0;
			h+=dotProduct(&xData[i*xRows],&xData[j*xRows],dim,gamma);
			h+=dotProduct(&yData[i*xRows],&yData[j*xRows],dim,gamma);
			h-=dotProduct(&xData[i*xRows],&yData[j*xRows],dim,gamma);
			h-=dotProduct(&yData[i*xRows],&xData[j*xRows],dim,gamma);
			MMD+=h;
			}
		}
	MMD/=samples*(samples-1)/2;

	 plhs[0]=mxCreateDoubleMatrix(1,1,mxREAL);
	*mxGetPr(plhs[0])=MMD;
}

