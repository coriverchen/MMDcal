% r=mmd(C,F,gamma)
%
% Calculates unbiassed estimated of MMD between data samples C and F.
% It is assumed that each column of C and F represents one measurement.
% C and F should have same number of columns (measurements). If not, lower
% number is used.
% MMD is calculated with Gaussian kernel k(x,y)=exp(gamma*\|x-y\|^2).
% gamma is width of Gaussian kernel.