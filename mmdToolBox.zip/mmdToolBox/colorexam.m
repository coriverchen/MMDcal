
C = importdata('\\wmc.i-yu.me\wyf\Color\feature\HILL\payload_0.4\cover_ppm_bic_CRM.mat');
C = C.F(1:1000,:);
S1 = importdata('\\wmc.i-yu.me\wyf\ColorExperiment\Feature\HILL_CMDgCrb_Pipayload0.4CRM5404.mat');
S2 = importdata('\\wmc.i-yu.me\wyf\Color\feature\HILL\payload_0.4\10000-CCMDgrbV2Color.mat');
S3 = importdata('\\wmc.i-yu.me\wyf\Color\feature\HILL\payload_0.4\10000-CCMDgrbV3Color.mat');
S4 = importdata('\\wmc.i-yu.me\wyf\Color\feature\HILL\payload_0.4\10000-CCMDgrbV11Color.mat');
S1 = S1.F(1:1000,:);
S2 = S2.F(1:1000,:);
S3 = S3.F(1:1000,:);
S4 = S4.F(1:1000,:);
% C = C';
% Stego = Stego';
%then, we calculate mean and standard deviation on cover images
[M,S]=MeanStd(C);

%so we can normalize the data
[nC,nS1,nS2,nS3,nS4]=normalize(M,S,C,S1,S2,S3,S4);
% [nC,nStego]=normalize(M,S,C,Stego);

%calculate the estimate of median from 200 randomly selected sample pairs
med=medianDist(nC,nC,200);

% set gamma according to median heuristics
gamma =1/(med^2);
gamma=1;

%finaly, calculate MMD
% disp(sprintf('MMD between cover and 100%% embedded images is %f ',mmd(nC,nS100,gamma)));
% disp(sprintf('MMD between cover and 50%% embedded images is %f ',mmd(nC,nS50,gamma)));
% disp(sprintf('MMD between cover and 25%% embedded images is %f ',mmd(nC,nS25,gamma)));
disp(sprintf('MMD between cover and S1 embedded images is %f ',mmd(nC,nS1,gamma)));
disp(sprintf('MMD between cover and S2 embedded images is %f ',mmd(nC,nS2,gamma)));
disp(sprintf('MMD between cover and S3 embedded images is %f ',mmd(nC,nS3,gamma)));
disp(sprintf('MMD between cover and S4 embedded images is %f ',mmd(nC,nS4,gamma)));
