/* Calculates MMD of samples X and Y */
/* MMD uses Gaussian kernel k(x,y)=exp(gamma*\|x-y\|^2*/
/* calling sequence is MMD(X,Y,gamma) */
/* (c) DDE laboratory, Binghamton University, SUNY */
/* author: Tomas Pevny, pevnak@gmail.com */


#include "mex.h"
#include "matrix.h"
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

void heapsort(int n, double *ra) {
    int i, j;
    int ir = n;
    int l = (n >> 1) + 1;
    double rra;

    for (;;) {
	if (l > 1) {
	    rra = ra[--l];
	} else {
	    rra = ra[ir];
	    ra[ir] = ra[1];
	    if (--ir == 1) {
		ra[0] = rra;
		return;
	    }
	}
	i = l;
	j = l << 1;
	while (j <= ir) {
	    if (j < ir && ra[j] < ra[j+1]) { ++j; }
	    if (rra < ra[j]) {
		ra[i] = ra[j];
		j += (i = j);
	    } else {
		j = ir + 1;
	    }
	}
	ra[i] = rra;
    }
}



/* Translate Matlab array to C array. It is a column major notation.
data(i,j)=data[j*rows + i]  */
int getDoubleArray(const mxArray *arg, double** x, int* rows, int* colls) {
  if (!arg) return -1;
  *rows = (int) mxGetM(arg);
  *colls = (int) mxGetN(arg);
  if (!mxIsNumeric(arg) || mxIsComplex(arg) || mxIsSparse(arg)  || !mxIsDouble(arg) ) {
	mexPrintf("Type of array should be double");
    *x= NULL;
    return -1;
  }
  *x = mxGetPr(arg);
  return 1;
}

int getDouble(const mxArray *arg, double *x) {
  int m, n;

  if (!arg) return -1;
  m = mxGetM(arg);
  n = mxGetN(arg);
  if (!mxIsNumeric(arg) || mxIsComplex(arg) || mxIsSparse(arg)  || !mxIsDouble(arg) ||
      (m != 1) || (n != 1)) {
    *x = 0.0;
    return -1;
  }
  *x = mxGetScalar(arg);
  return 1;
}


/*L2 distance between x and y*/
double L2Dist(double* x,double* y, int dim){
	double result=0;
	int i=0;
	for(i=0;i<dim;i++) {
		result+=(x[i]-y[i])*(x[i]-y[i]);
		/*mexPrintf("%e %e %e \n",x[i],y[i],(x[i]-y[i])); */
		}
	return result;
	}

/*assign sample from appropriate data set according to the sampleNo */
double* assignSample(double **data,int *samples,int dim,int dataSets, int sampleNo){
	int i=0;
	while (i<dataSets){

		if (sampleNo<samples[i]){
			return data[i]+sampleNo*dim;
			}
		i=i+1;
		sampleNo-=samples[i];
		}

	/* *we should never be here, return null; */
	return NULL;
	}

/*this functions free parameters that were allocated */
void freeIfNeeded(double **data,int dataLength,int *samples,double *distances){
	if (data!=NULL) {
		mxFree(data);
		};

	if (samples!=NULL){
		mxFree(samples);
		};

	if (distances!=NULL){
		mxFree(distances);
		};
}

/*Main function */
void mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[]){
	double **data=NULL;
	int *samples=NULL;
	double *distances=NULL;
	int dim= (int) mxGetM(prhs[0]);
	int samplesCount=0;
	int i=0;
	double temp=0.0;
	int stats=0;


	if (nrhs<2) {
		mexPrintf("\nFunction needs at least 2 parameters: medianDist(X1,X2,...,stats)\n");
		mexPrintf("Xi are matrices with samples. Each column is one sample,  matrices have to have same number of rows.\n");
		mexPrintf("stats is the size of statistics of distances that will be calculated. We do not calculate exact median, \n");
		mexPrintf("because it will take too much time and it is not needed.\n");
		return;
		}

	/*get matrices with samples */
	data=mxCalloc(nrhs-1,sizeof(double*));
	if (data==NULL){
    	mexPrintf("Failed to allocate arrays.\n");
		return;
        }
	/*initialize matrices to zero, so we can free them */
	for(i=0;i<nrhs-1;i++){
		data[i]=NULL;
		}

	samples=mxCalloc(nrhs-1,sizeof(int));
    if (samples==NULL){
    	mexPrintf("Failed to allocate arrays.\n");
		/*freeIfNeeded(data,nrhs-1,samples,distances);*/
		return;
        }
	for (i=0;i<nrhs-1;i++){
		int testDim=0,newSamp=0;
		if (getDoubleArray(prhs[i],&data[i],&testDim,&newSamp)==-1){
			mexPrintf("Failed to extract matrices from the parameters.");
			freeIfNeeded(data,nrhs-1,samples,distances);
			return;
			}
		if (testDim!=dim){
			mexPrintf("All samples has to have same dimension\n");
			/*freeIfNeeded(data,nrhs-1,samples,distances);*/
			return;
			}
		/*update statistics about number of samples */
		samplesCount+=newSamp;
		samples[i]=newSamp;
		/*mexPrintf("added matrix with %d samples\n",samples[i]);*/
		}


	/*Debugging function. Let's save all matrices */

	/*extract size of statistics that is going to be used to calculate the median */
	temp=0.0;
	if (getDouble(prhs[nrhs-1],&temp)==-1){
		mexPrintf("Failed to extract size of the statistics to calculate median\n");
		/*freeIfNeeded(data,nrhs-1,samples,distances);*/
		return;
		}
	stats=(int)temp;

	/*now, we can finally calculate MMD value */
	distances=(double*)mxCalloc(stats,sizeof(double));
	if (distances==NULL){
		mexPrintf("Failed to allocate memory for distances\n");
		/*freeIfNeeded(data,nrhs-1,samples,distances);*/
		return;
		}

	/*finally, we can calculate statistics for median */
	for (i=0;i<stats;i++){
		/*randomly select two samples */
 		int k=rand()%samplesCount;
		int l=rand()%samplesCount;
		double *x=NULL,*y=NULL;
		while (k==l){
			l=rand()%samplesCount;
			};

		/*mexPrintf("%d:  k = %d l = %d\n",i,k,l);*/
		/* asign sample vectors according randomly generated position */
		x=assignSample(data,samples,dim,nrhs-1,k);
		y=assignSample(data,samples,dim,nrhs-1,l);

		if ((x==NULL)||(y==NULL)){
			mexPrintf("Failed to assign sample from dataset\n");
			freeIfNeeded(data,nrhs-1,samples,distances);
			return;
			}
		distances[i]=L2Dist(x,y,dim);
		}

	/* if there the size of statistics is larger than one, sort it */
	if (stats>1){
		heapsort(stats-1,distances);
		}

	 plhs[0]=mxCreateDoubleMatrix(1,1,mxREAL);
	if (stats>0){
		*mxGetPr(plhs[0])=sqrt(distances[(int)floor(stats/2)]);
		} else {
		mexPrintf("??? Stats<=0 ???\n");
		*mxGetPr(plhs[0])=0.0;
		}

	/*free allocated memory */
	/*freeIfNeeded(data,nrhs-1,samples,distances);*/
}

