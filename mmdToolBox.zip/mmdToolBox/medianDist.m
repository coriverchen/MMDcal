%m=medianDist(wC1,wC2,wC3,...,wCn,samples)
%
%medianDist(wC1,wC2,wC3,...,wCn,samples)
%estimates median of L_2 distances between
%samples in matrices wC1,wC2,wC3,...,wCn. Any number of matrices can be
%included, at least one is needed. The parameter samples specifies, how many
%randomly chosen pairs of data samples would be used to estimate the median of
%the distances.
