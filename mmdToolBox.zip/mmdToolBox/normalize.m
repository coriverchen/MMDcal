function [varargout]=normalize(M,S,varargin)
%function [X1,X2,X3,...]=normalize(mean,std,D1,D2,D3,...)
%normalizes data by given mean and std
%mean and std should be column vectors
%
% (c) Tomas Pevny, DDE laboratory 2008, pevnak@gmail.com

if (nargin>1)
	other=varargin;
	N=length(other);
	for k=1:N
    	[m,n] = size(other{k});
    	T=other{k}-M*ones(1,n);
		T=T./(S*ones(1,n));
		varargout{k}=T;
	end
end
