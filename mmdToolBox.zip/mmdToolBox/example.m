
%first, we load the data samples
C=load('example/cover.fea');
S100=load('example/stego_100.fea');
S50=load('example/stego_50.fea');
S25=load('example/stego_25.fea');

% The matrices with data has to be transposed, because toolbox assumes
% each column of the matrix is one measurement
C=C';
S100=S100';
S50=S50';
S25=S25';

%then, we calculate mean and standard deviation on cover images
[M,S]=MeanStd(C);

%so we can normalize the data
[nC,nS100,nS50,nS25]=normalize(M,S,C,S100,S50,S25);

%calculate the estimate of median from 200 randomly selected sample pairs
med=medianDist(nC,nC,200)

% set gamma according to median heuristics
gamma =1/(med^2);
gamma=2;

%finaly, calculate MMD
disp(sprintf('MMD between cover and 100%% embedded images is %f ',mmd(nC,nS100,gamma)));
disp(sprintf('MMD between cover and 50%% embedded images is %f ',mmd(nC,nS50,gamma)));
disp(sprintf('MMD between cover and 25%% embedded images is %f ',mmd(nC,nS25,gamma)));