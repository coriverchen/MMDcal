%[M,S]=MeanStd(C1,C2,...);
%calculates parameters of normalization --- mean M and standard deviation S.
%If function MeanStd is supplied with more than one matrix, the mean and
%standard deviation is calculated over all matrices. All matrices have to have
%same number of rows. The result of the calculation of mean and standard
%deviation over more matrices can be written in matlab syntax as
%[MeanStd(C1,C2,C3,...,Cn)]=MeanStd([C1;C2;C3;...;Cn])