/* Calculates MMD of samples X and Y */
/* MMD uses Gaussian kernel k(x,y)=exp(gamma*\|x-y\|^2*/
/* calling sequence is MMD(X,Y,gamma) */
/* (c) DDE laboratory, Binghamton University, SUNY */
/* author: Tomas Pevny, pevnak@gmail.com */


#include "mex.h"
#include "matrix.h"
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

/* Translate Matlab array to C array. It is a column major notation.
data(i,j)=data[j*rows + i]  */
int getDoubleArray(const mxArray *arg, double** x, int* rows, int* colls) {
  if (!arg) return -1;
  *rows = (int) mxGetM(arg);
  *colls = (int) mxGetN(arg);
  if (!mxIsNumeric(arg) || mxIsComplex(arg) || mxIsSparse(arg)  || !mxIsDouble(arg) ) {
	mexPrintf("Type of array should be double");
    *x= NULL;
    return -1;
  }
  *x = mxGetPr(arg);
  return 1;
}

int getDouble(const mxArray *arg, double *x) {
  int m, n;

  if (!arg) return -1;
  m = mxGetM(arg);
  n = mxGetN(arg);
  if (!mxIsNumeric(arg) || mxIsComplex(arg) || mxIsSparse(arg)  || !mxIsDouble(arg) ||
      (m != 1) || (n != 1)) {
    *x = 0.0;
    return -1;
  }
  *x = mxGetScalar(arg);
  return 1;
}


/*add x to mean*/
void add(double* x,double* mean,int dim){
	int i=0;
	for(i=0;i<dim;i++) {
		mean[i]+=x[i];
		}
	}

/*add x to mean*/
void addSQ(double* x,double* var,int dim){
	int i=0;
	for(i=0;i<dim;i++) {
		var[i]+=x[i]*x[i];
		}
	}


/*Main function */
void mexFunction(int nlhs,mxArray *plhs[],int nrhs,const mxArray *prhs[]){
	/*Get dimension of the data */
	int dim= (int) mxGetM(prhs[0]);
	int samples=0;
	int i=0,k=0;

	double *mean,*var;

	if (nrhs<1) {
		mexPrintf("\nFunction needs at least 1 parameters: [mean,std]=MeanStd(X1,X2,...)\n");
		mexPrintf("Each column of a matrix is a sample, which yields to the requirement that all matrices has to have same number of columns.\n");
		mexPrintf("Function returns 2 vectors, mean and std of data\n");
		return;
		}

	if (nlhs<2) {
		mexPrintf("\nFunction returns 2 parameters: [mean,std]=MeanStd(X,Y)\n");
		mexPrintf("X and Y are matrices with samples. Each column is one sample, both matrices has to have same number of rows.\n");
		mexPrintf("Function returns 2 vectors, mean and std of data\n");
		mexPrintf("\n\n Provide two outputs\n");
		return;
		}

	/*Allocate space for results -- mean and variance */
	plhs[0]=mxCreateDoubleMatrix(dim,1,mxREAL);
	mean=mxGetPr(plhs[0]);
	plhs[1]=mxCreateDoubleMatrix(dim,1,mxREAL);
	var=mxGetPr(plhs[1]);

	/*init them to zero */
	for (i=0;i<dim;i++){
		var[i]=0.0;
		mean[i]=0.0;
		};

	for (k=0;k<nrhs;k++){
		/*get matrices with samples */
		double *xData=NULL;
		int xRows=0,xColls=0;
		if (getDoubleArray(prhs[k],&xData,&xRows,&xColls)==-1){
			mexPrintf("Failed to extract matrices from the parameters.\n");
			return;
			}

		if (xRows!=dim){
			mexPrintf("Matrix %d has different number of rows (dimension of samples)\n",k);
			return;
			}

		/*update statistics on data */
		for (i=0;i<xColls;i++){
			double* x=xData + i*xRows;
			add(x,mean,dim);
			addSQ(x,var,dim);
			samples+=1;
			}
		}

	if (samples<1){
			mexPrintf("At least one sample is needed to calculate statistics\n");
			return;
			}

	/*post-process statistics */
	for (i=0;i<dim;i++){
		mean[i]/=samples;
		var[i]=sqrt(var[i]/samples-mean[i]*mean[i]);
		};
}

